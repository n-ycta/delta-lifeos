import { icon } from "./icons";
import "../ui/controls.css";
/** Enhances form selects without changing their values, names or change events. */
export function styledControls() {
  const known = new WeakSet<HTMLSelectElement>();
  let close: () => void = () => {};
  const enhance = (s: HTMLSelectElement) => {
    if (known.has(s) || s.multiple) return;
    known.add(s);
    const wrap = document.createElement("span");
    wrap.className = "delta-select";
    s.before(wrap);
    wrap.append(s);
    s.classList.add("delta-select-native");
    s.tabIndex = -1;
    s.setAttribute("aria-hidden", "true");
    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.className = "delta-select-trigger";
    trigger.setAttribute("role", "combobox");
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");
    trigger.setAttribute(
      "aria-label",
      s.getAttribute("aria-label") ||
        s.labels?.[0]?.textContent ||
        s.name ||
        "Select",
    );
    wrap.append(trigger);
    const label = document.createElement("span");
    trigger.append(label);
    trigger.insertAdjacentHTML("beforeend", icon("caret-down"));
    const update = () => {
      label.textContent = s.selectedOptions[0]?.textContent || "";
      trigger.disabled = s.disabled;
    };
    update();
    s.addEventListener("change", update);
    s.addEventListener("focus", () => trigger.focus());
    trigger.addEventListener("click", () => {
      close();
      const popup = document.createElement("div");
      popup.className = "delta-select-popup";
      popup.setAttribute("role", "listbox");
      popup.tabIndex = 0;
      const options = Array.from(s.options);
      let at = Math.max(0, s.selectedIndex);
      const choose = (i: number) => {
        if (options[i]?.disabled) return;
        s.selectedIndex = i;
        s.dispatchEvent(new Event("change", { bubbles: true }));
        close();
        trigger.focus();
      };
      const items = options.map((o, i) => {
        const b = document.createElement("button");
        b.type = "button";
        b.tabIndex = -1;
        b.setAttribute("role", "option");
        b.setAttribute("aria-selected", String(o.selected));
        b.disabled = o.disabled;
        b.textContent = o.textContent;
        b.addEventListener("click", () => choose(i));
        popup.append(b);
        return b;
      });
      const focused = () =>
        items.forEach((b, i) => b.classList.toggle("focused", i === at));
      focused();
      const parent = s.closest("dialog") || document.body;
      parent.append(popup);
      const r = trigger.getBoundingClientRect();
      popup.style.cssText = `left:${Math.max(8, Math.min(r.left, innerWidth - Math.max(r.width, 160) - 8))}px;top:${r.bottom + 8 + Math.min(280, options.length * 40) > innerHeight ? Math.max(8, r.top - Math.min(280, options.length * 40) - 8) : r.bottom + 8}px;width:${Math.max(r.width, 160)}px;`;
      trigger.setAttribute("aria-expanded", "true");
      popup.focus();
      const outside = (e: PointerEvent) => {
        if (
          !popup.contains(e.target as Node) &&
          !trigger.contains(e.target as Node)
        )
          close();
      };
      const scroll = (e: Event) => {
        if (!popup.contains(e.target as Node)) close();
      };
      close = () => {
        popup.remove();
        trigger.setAttribute("aria-expanded", "false");
        document.removeEventListener("pointerdown", outside);
        window.removeEventListener("resize", close);
        window.removeEventListener("scroll", scroll, true);
        close = () => {};
      };
      document.addEventListener("pointerdown", outside);
      window.addEventListener("resize", close);
      window.addEventListener("scroll", scroll, true);
      popup.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          e.stopPropagation();
          close();
          trigger.focus();
        } else if (e.key === "Tab") close();
        else if (["Enter", " "].includes(e.key)) {
          e.preventDefault();
          choose(at);
        } else if (["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) {
          e.preventDefault();
          at =
            e.key === "Home"
              ? 0
              : e.key === "End"
                ? items.length - 1
                : (at + (e.key === "ArrowDown" ? 1 : -1) + items.length) %
                  items.length;
          focused();
          items[at].scrollIntoView({ block: "nearest" });
        }
      });
    });
  };
  const scan = () => {
    document.querySelectorAll<HTMLSelectElement>("select").forEach(enhance);
  };
  const observer = new MutationObserver(scan);
  observer.observe(document.body, { childList: true, subtree: true });
  scan();
  window.addEventListener(
    "pagehide",
    () => {
      observer.disconnect();
      close();
    },
    { once: true },
  );
}
