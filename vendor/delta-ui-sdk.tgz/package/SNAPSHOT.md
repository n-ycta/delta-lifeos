Local packaging of actual Delta UI SDK source with the accompanying host patch. Not an official published @delta/ui release. See the handoff patches and verification report.
